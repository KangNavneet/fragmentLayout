package com.navneetkang.uglyapp;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    int countA=0;
    int countB=0;
    int scoreA=0;
    int scoreB=0;
    int score=0;
    Bundle bundle;
    TextView teamAScore;
    TextView teamBScore;
    RadioButton  wide,four,six;
    TextView result;
    TextView setRules;
    RadioGroup rg;
    RadioButton r1,r4,r6;

    MediaPlayer mp;
    TableLayout l1;
    TextView themepercent;
    SeekBar seek;
    SharedPreferences.Editor editor;
    SharedPreferences sharedPreferences;
    String check;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        l1= findViewById(R.id.scrollViewBackground);
        r1=findViewById(R.id.score_1);
        r4=findViewById(R.id.score_4);
        r6=findViewById(R.id.score_6);

        //seek=findViewById(R.id.seekBar);
        //themepercent=findViewById(R.id.themePercent);
        sharedPreferences=getSharedPreferences("mypref",MODE_PRIVATE);
        editor=sharedPreferences.edit();
        //final Button activeTeamB=findViewById(R.id.active_teamB);



        Button increaseScoreA=findViewById(R.id.team_a_increase);
        Button increaseScoreB=findViewById(R.id.team_b_increase);
        Button decreaseScoreA=findViewById(R.id.team_a_decrease);
        Button decreaseScoreB=findViewById(R.id.team_b_decrease);
        rg=findViewById(R.id.scoreChange);


        wide=findViewById(R.id.score_1);
        four=findViewById(R.id.score_4);
        six=findViewById(R.id.score_6);

        teamAScore=findViewById(R.id.teamAScore);
        teamBScore=findViewById(R.id.teamBScore);
        int a = sharedPreferences.getInt("teamA",0);
        int b= sharedPreferences.getInt("teamB", 0);
        int c=sharedPreferences.getInt("score",0);
        Log.d("MyMessage",c+"");
        check=sharedPreferences.getString("remValue", null);
        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                selectRadio();
            }
        });

        Toast.makeText(this,check,Toast.LENGTH_LONG).show();
        if(check!=null) {
            if (check.equals("checked")) {
                scoreA = a ;
                scoreB = b ;
                score=c;

                update();
            }
            else
            {
                scoreA = 0 ;
                scoreB = 0 ;
                score=0;

                update();
            }
        }






        increaseScoreA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                buttonClick();
                selectRadio();
                scoreA+=score;
                update();

            }
        });
        increaseScoreB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                buttonClick();
                selectRadio();
                scoreB+=score;
                update();
            }
        });

        decreaseScoreA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                buttonClick();
                selectRadio();
                scoreA-=score;
                update();


            }
        });

        decreaseScoreB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                buttonClick();
                selectRadio();
                scoreB-=score;

                update();

            }
        });

    }
    public void buttonClick()
    {
      // mp=MediaPlayer.create(getApplicationContext(),R.raw.button_press);
       // mp.start();
    }

    public void update()
    {


        teamAScore.setText(scoreA+"");
        teamBScore.setText(scoreB+"");
        if(check!=null)
        {
            Log.d("MyMessage",score+"");

            if(check.equals("checked"))
            {
                if(score==1)
                {
                    r1.setChecked(true);
                }
                else if(score==4)
                {
                    r4.setChecked(true);
                }
                else if(score==6)
                {
                    r6.setChecked(true);
                }

                putData();
                editor.putInt("teamA",scoreA);
                editor.putInt("teamB",scoreB);

                editor.putInt("score",score);
                editor.commit();



            }
            else
            {
                check=sharedPreferences.getString("remValue", null);
            }
        }





    }


    public void selectRadio()
    {
        switch(rg.getCheckedRadioButtonId())
        {
            case R.id.score_1:
                score=1;
                break;


            case R.id.score_4:
                score=4;
                break;


            case R.id.score_6:
                score=6;
                break;

        }

    }
/********************MENU********************/
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.my_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId())
        {
            case R.id.settings:
                Toast.makeText(this, "Settings", Toast.LENGTH_SHORT).show();

                Intent intent=new Intent(this,settingActivity.class);
                putData();
                intent.putExtras(bundle);
                startActivity(intent);

                break;

            case R.id.info:
                Toast.makeText(this, "Info", Toast.LENGTH_SHORT).show();
                Intent intent1=new Intent(this,infoActivity.class);
                startActivity(intent1);
                break;

            default:
                Toast.makeText(this, "Default", Toast.LENGTH_SHORT).show();

        }
        return super.onOptionsItemSelected(item);
    }

    public void putData()
    {

        bundle = new Bundle();
        bundle.putInt("teamA",scoreA);
        bundle.putInt("teamB",scoreB);
        Log.d("MyMessage Put Data",score+"");
        bundle.putInt("score",score);


    }


}

