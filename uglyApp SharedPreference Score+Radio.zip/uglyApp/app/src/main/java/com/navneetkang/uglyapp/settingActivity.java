package com.navneetkang.uglyapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Toast;

public class settingActivity extends AppCompatActivity {
    CheckBox rememberValues;
    SharedPreferences.Editor editor;
    SharedPreferences sharedPreferences;
    int teamA,teamB,score;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        rememberValues=findViewById(R.id.rememberValues);
        Bundle bundle = getIntent().getExtras();
        teamA=bundle.getInt("teamA");
        teamB=bundle.getInt("teamB");
        score=bundle.getInt("score");

        sharedPreferences=getSharedPreferences("mypref",MODE_PRIVATE);
        editor=sharedPreferences.edit();
        checkValue();


        Toast.makeText(getApplicationContext(),"TEAM A:"+teamA,Toast.LENGTH_LONG).show();
        Toast.makeText(getApplicationContext(),"TEAM B:"+teamB,Toast.LENGTH_LONG).show();

        rememberValues.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                SharedPreferences.Editor checkVal;
                if(rememberValues.isChecked())
                {

                    Toast.makeText(getApplicationContext(),"Checked",Toast.LENGTH_LONG).show();
                     editor.putString("remValue","checked");
                     editor.putInt("teamA",teamA);
                     editor.putInt("teamB",teamB);
                     editor.putInt("score",score);
                     editor.commit();
                     checkValue();


                }
                else
                {
                    Toast.makeText(getApplicationContext(),"Not Checked",Toast.LENGTH_LONG).show();
                    editor.putString("remValue","notChecked");
                    editor.putInt("teamA",0);
                    editor.putInt("teamB",0);
                    editor.putInt("score",0);
                    editor.commit();
                    checkValue();
                }
            }
        });
    }

    public void checkValue()
    {
        String checkVal=sharedPreferences.getString("remValue",null);
        if(checkVal!=null) {
            if (checkVal.equals("checked")) {
                Log.d("MyMessage", checkVal);

                rememberValues.setChecked(true);
            } else {
                Log.d("MyMessage", checkVal);
                rememberValues.setChecked(false);
            }


        }
    }
}